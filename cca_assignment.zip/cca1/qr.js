function generateQR() {
    var text = document.getElementById("textInput").value;
    console.log("Input text:", text); // Add this line for debugging
    if (text !== "") {
        // Clear previous QR code if exists
        document.getElementById("qrcode").innerHTML = "";
        // Generate QR code
        var qr = new QRious({
            element: document.getElementById("qrcode"),
            value: text,
            size: 300
        });
    } else {
        alert("Please enter text or URL.");
    }
}
